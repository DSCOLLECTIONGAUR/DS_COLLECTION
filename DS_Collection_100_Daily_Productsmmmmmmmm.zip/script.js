const WHATSAPP_NUMBER = "9779765894505";

const products = [
  {id:1,name:'Premium Saree',price:2500,category:'Fashion',icon:'🥻'},
  {id:2,name:'Ladies Kurti',price:1200,category:'Fashion',icon:'👗'},
  {id:3,name:"Men's Shirt",price:900,category:'Fashion',icon:'👔'},
  {id:4,name:'T-Shirt',price:650,category:'Fashion',icon:'👕'},
  {id:5,name:'Rice 1kg',price:150,category:'Grocery',icon:'🍚'},
  {id:6,name:'Rice 5kg',price:750,category:'Grocery',icon:'🍚'},
  {id:7,name:'Basmati Rice 1kg',price:240,category:'Grocery',icon:'🍚'},
  {id:8,name:'Chiura 1kg',price:190,category:'Grocery',icon:'🍚'},
  {id:9,name:'Dal Masoor 1kg',price:180,category:'Grocery',icon:'🫘'},
  {id:10,name:'Dal Rahar 1kg',price:220,category:'Grocery',icon:'🫘'},
  {id:11,name:'Dal Moong 1kg',price:210,category:'Grocery',icon:'🫘'},
  {id:12,name:'Chana 1kg',price:150,category:'Grocery',icon:'🫘'},
  {id:13,name:'Sugar 1kg',price:130,category:'Grocery',icon:'🧂'},
  {id:14,name:'Salt 1kg',price:30,category:'Grocery',icon:'🧂'},
  {id:15,name:'Cooking Oil 1L',price:210,category:'Grocery',icon:'🫗'},
  {id:16,name:'Mustard Oil 1L',price:220,category:'Grocery',icon:'🫗'},
  {id:17,name:'Ghee 500ml',price:450,category:'Grocery',icon:'🧈'},
  {id:18,name:'Tea 250g',price:160,category:'Grocery',icon:'🍵'},
  {id:19,name:'Coffee 100g',price:220,category:'Grocery',icon:'☕'},
  {id:20,name:'Noodles 5 Pack',price:100,category:'Grocery',icon:'🍜'},
  {id:21,name:'Pasta 500g',price:156,category:'Grocery',icon:'🍝'},
  {id:22,name:'Soya Chunk 200g',price:52,category:'Grocery',icon:'🫘'},
  {id:23,name:'Biscuits 150g',price:48,category:'Grocery',icon:'🍪'},
  {id:24,name:'Bread',price:70,category:'Grocery',icon:'🍞'},
  {id:25,name:'Jam 500g',price:220,category:'Grocery',icon:'🍓'},
  {id:26,name:'Peanut Butter 340g',price:350,category:'Grocery',icon:'🥜'},
  {id:27,name:'Corn Flakes 500g',price:350,category:'Grocery',icon:'🥣'},
  {id:28,name:'Oats 500g',price:280,category:'Grocery',icon:'🥣'},
  {id:29,name:'Popcorn 1kg',price:161,category:'Grocery',icon:'🍿'},
  {id:30,name:'Turmeric Powder 100g',price:45,category:'Spices',icon:'🟡'},
  {id:31,name:'Chilli Powder 100g',price:50,category:'Spices',icon:'🌶️'},
  {id:32,name:'Cumin Powder 100g',price:70,category:'Spices',icon:'🟤'},
  {id:33,name:'Coriander Powder 100g',price:45,category:'Spices',icon:'🌿'},
  {id:34,name:'Garam Masala 50g',price:60,category:'Spices',icon:'🌿'},
  {id:35,name:'Black Pepper 50g',price:100,category:'Spices',icon:'⚫'},
  {id:36,name:'Ginger Garlic Paste 200g',price:100,category:'Grocery',icon:'🧄'},
  {id:37,name:'Tomato Sauce 500g',price:150,category:'Grocery',icon:'🍅'},
  {id:38,name:'Soy Sauce 250ml',price:100,category:'Grocery',icon:'🥣'},
  {id:39,name:'Vinegar 500ml',price:90,category:'Grocery',icon:'🍶'},
  {id:40,name:'Papad 200g',price:90,category:'Grocery',icon:'🥨'},
  {id:41,name:'Bath Soap',price:80,category:'Personal Care',icon:'🧼'},
  {id:42,name:'Hand Wash 250ml',price:120,category:'Personal Care',icon:'🧴'},
  {id:43,name:'Shampoo 180ml',price:180,category:'Personal Care',icon:'🧴'},
  {id:44,name:'Hair Oil 200ml',price:150,category:'Personal Care',icon:'🧴'},
  {id:45,name:'Toothpaste 100g',price:120,category:'Personal Care',icon:'🪥'},
  {id:46,name:'Toothbrush',price:50,category:'Personal Care',icon:'🪥'},
  {id:47,name:'Face Wash',price:220,category:'Personal Care',icon:'🧴'},
  {id:48,name:'Body Lotion 200ml',price:250,category:'Personal Care',icon:'🧴'},
  {id:49,name:'Deodorant',price:250,category:'Personal Care',icon:'🧴'},
  {id:50,name:'Comb',price:40,category:'Personal Care',icon:'💇'},
  {id:51,name:'Tissue Box',price:100,category:'Personal Care',icon:'🧻'},
  {id:52,name:'Toilet Paper 4 Roll',price:180,category:'Personal Care',icon:'🧻'},
  {id:53,name:'Dishwash Liquid 500ml',price:150,category:'Home',icon:'🧽'},
  {id:54,name:'Dishwash Bar',price:30,category:'Home',icon:'🧼'},
  {id:55,name:'Laundry Detergent 1kg',price:180,category:'Home',icon:'🫧'},
  {id:56,name:'Laundry Soap',price:35,category:'Home',icon:'🧼'},
  {id:57,name:'Toilet Cleaner 500ml',price:180,category:'Home',icon:'🧴'},
  {id:58,name:'Floor Cleaner 1L',price:180,category:'Home',icon:'🧹'},
  {id:59,name:'Glass Cleaner',price:160,category:'Home',icon:'🪟'},
  {id:60,name:'Bleach 500ml',price:100,category:'Home',icon:'🧴'},
  {id:61,name:'Scrub Pad',price:30,category:'Home',icon:'🧽'},
  {id:62,name:'Sponge',price:40,category:'Home',icon:'🧽'},
  {id:63,name:'Broom',price:150,category:'Home',icon:'🧹'},
  {id:64,name:'Mop',price:300,category:'Home',icon:'🧹'},
  {id:65,name:'Garbage Bags',price:100,category:'Home',icon:'🗑️'},
  {id:66,name:'Mosquito Coil',price:80,category:'Home',icon:'🦟'},
  {id:67,name:'Mosquito Repellent',price:250,category:'Home',icon:'🦟'},
  {id:68,name:'Match Box',price:10,category:'Home',icon:'🔥'},
  {id:69,name:'Kitchen Container Set',price:650,category:'Kitchen',icon:'🍱'},
  {id:70,name:'Plastic Bucket',price:250,category:'Kitchen',icon:'🪣'},
  {id:71,name:'Mug',price:80,category:'Kitchen',icon:'🥤'},
  {id:72,name:'Water Bottle',price:180,category:'Kitchen',icon:'🍼'},
  {id:73,name:'Lunch Box',price:250,category:'Kitchen',icon:'🍱'},
  {id:74,name:'Steel Plate',price:120,category:'Kitchen',icon:'🍽️'},
  {id:75,name:'Steel Glass',price:100,category:'Kitchen',icon:'🥛'},
  {id:76,name:'Spoon Set',price:150,category:'Kitchen',icon:'🥄'},
  {id:77,name:'Knife',price:120,category:'Kitchen',icon:'🔪'},
  {id:78,name:'Storage Container',price:120,category:'Kitchen',icon:'🫙'},
  {id:79,name:'Aluminium Foil',price:150,category:'Kitchen',icon:'📦'},
  {id:80,name:'Cling Film',price:120,category:'Kitchen',icon:'📦'},
  {id:81,name:'LED Bulb 9W',price:120,category:'Electrical',icon:'💡'},
  {id:82,name:'LED Bulb 12W',price:150,category:'Electrical',icon:'💡'},
  {id:83,name:'Extension Board',price:450,category:'Electrical',icon:'🔌'},
  {id:84,name:'Mobile Charger',price:450,category:'Accessories',icon:'🔌'},
  {id:85,name:'USB Cable',price:180,category:'Accessories',icon:'🔌'},
  {id:86,name:'Earphones',price:250,category:'Accessories',icon:'🎧'},
  {id:87,name:'Power Bank',price:1200,category:'Accessories',icon:'🔋'},
  {id:88,name:'Umbrella',price:350,category:'Daily Use',icon:'☂️'},
  {id:89,name:'Notebook',price:80,category:'Stationery',icon:'📓'},
  {id:90,name:'Ball Pen',price:20,category:'Stationery',icon:'🖊️'},
  {id:91,name:'Pencil Pack',price:40,category:'Stationery',icon:'✏️'},
  {id:92,name:'School Bag',price:700,category:'Stationery',icon:'🎒'},
  {id:93,name:'Water Bottle Kids',price:180,category:'Daily Use',icon:'🧴'},
  {id:94,name:'Torch Light',price:250,category:'Daily Use',icon:'🔦'},
  {id:95,name:'Wall Clock',price:450,category:'Home',icon:'🕐'},
  {id:96,name:'Bedsheet',price:650,category:'Home',icon:'🛏️'},
  {id:97,name:'Towel',price:250,category:'Daily Use',icon:'🧺'},
  {id:98,name:'Hair Clips',price:60,category:'Personal Care',icon:'🎀'},
  {id:99,name:'Nail Cutter',price:60,category:'Personal Care',icon:'✂️'},
  {id:100,name:'Sanitary Pads Pack',price:120,category:'Personal Care',icon:'🩷'}
];

let cart = JSON.parse(localStorage.getItem("ds_cart") || "[]");
let activeCategory = "All";

const $ = id => document.getElementById(id);
const money = n => "Rs. " + Number(n).toLocaleString("en-IN");

function renderCategories(){
  const cats = ["All", ...new Set(products.map(p => p.category))];
  $("categories").innerHTML = cats.map(cat =>
    `<button class="category ${cat===activeCategory ? "active" : ""}" data-category="${cat}">${cat}</button>`
  ).join("");

  document.querySelectorAll(".category").forEach(btn => {
    btn.addEventListener("click", () => {
      activeCategory = btn.dataset.category;
      renderCategories();
      renderProducts();
    });
  });
}

function renderProducts(){
  const q = $("searchInput").value.toLowerCase().trim();
  const list = products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    (p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q))
  );

  $("productGrid").innerHTML = list.length ? list.map(p => `
    <article class="product">
      <div class="product-img">${p.icon}</div>
      <div class="product-body">
        <div class="product-cat">${p.category}</div>
        <h3>${p.name}</h3>
        <div class="price">${money(p.price)}</div>
        <button class="add-btn" data-add="${p.id}">Add to Cart</button>
      </div>
    </article>
  `).join("") : "<p>No products found.</p>";

  document.querySelectorAll("[data-add]").forEach(btn =>
    btn.addEventListener("click", () => addToCart(Number(btn.dataset.add)))
  );
}

function addToCart(id){
  const item = cart.find(x => x.id === id);
  if(item) item.qty++;
  else cart.push({id,qty:1});
  saveCart();
  toast("Added to cart");
}

function changeQty(id,delta){
  const item = cart.find(x => x.id === id);
  if(!item) return;
  item.qty += delta;
  if(item.qty <= 0) cart = cart.filter(x => x.id !== id);
  saveCart();
}

function saveCart(){
  localStorage.setItem("ds_cart",JSON.stringify(cart));
  renderCart();
}

function renderCart(){
  const count = cart.reduce((s,x) => s+x.qty,0);
  $("cartCount").textContent = count;

  if(!cart.length){
    $("cartItems").innerHTML = '<p style="color:#777">Your cart is empty.</p>';
    $("cartTotal").textContent = money(0);
    return;
  }

  let total = 0;
  $("cartItems").innerHTML = cart.map(x => {
    const p = products.find(a => a.id === x.id);
    if(!p) return "";
    const sub = p.price*x.qty;
    total += sub;
    return `<div class="cart-item">
      <div><h4>${p.icon} ${p.name}</h4><small>${money(p.price)} each</small></div>
      <div style="text-align:right"><strong>${money(sub)}</strong>
        <div class="qty">
          <button data-minus="${p.id}">−</button><span>${x.qty}</span><button data-plus="${p.id}">+</button>
        </div>
      </div>
    </div>`;
  }).join("");

  $("cartTotal").textContent = money(total);
  document.querySelectorAll("[data-minus]").forEach(b => b.addEventListener("click",()=>changeQty(Number(b.dataset.minus),-1)));
  document.querySelectorAll("[data-plus]").forEach(b => b.addEventListener("click",()=>changeQty(Number(b.dataset.plus),1)));
}

function openCart(){ $("cartDrawer").style.display="block"; }
function closeCart(){ $("cartDrawer").style.display="none"; }
function openModal(){ if(!cart.length){toast("Your cart is empty");return;} $("orderModal").style.display="grid"; }
function closeModal(){ $("orderModal").style.display="none"; }

function toast(text){
  const t=$("toast"); t.textContent=text; t.classList.add("show");
  setTimeout(()=>t.classList.remove("show"),1800);
}

$("cartBtn").addEventListener("click",openCart);
$("closeCart").addEventListener("click",closeCart);
$("checkoutBtn").addEventListener("click",()=>{closeCart();openModal();});
$("closeModal").addEventListener("click",closeModal);
$("searchInput").addEventListener("input",renderProducts);

$("orderForm").addEventListener("submit",function(e){
  e.preventDefault();

  const name=$("customerName").value.trim();
  const phone=$("customerPhone").value.trim();
  const address=$("customerAddress").value.trim();
  const note=$("customerNote").value.trim();

  if(!name || !phone || !address){
    alert("Please fill Name, Mobile Number and Delivery Address.");
    return;
  }

  let total=0;
  const lines=cart.map((x,i)=>{
    const p=products.find(a=>a.id===x.id);
    const sub=p.price*x.qty;
    total+=sub;
    return `${i+1}. ${p.name} x ${x.qty} = ${money(sub)}`;
  });

  const message=[
    "🛍️ *NEW ORDER - DS COLLECTION*",
    "",
    ...lines,
    "",
    `💰 *Total: ${money(total)}*`,
    "",
    `👤 Name: ${name}`,
    `📱 Mobile: ${phone}`,
    `📍 Address: ${address}`,
    "🚚 Delivery: Gaur only, within 1 day",
    note ? `📝 Note: ${note}` : ""
  ].filter(Boolean).join("\n");

  const url="https://wa.me/"+WHATSAPP_NUMBER+"?text="+encodeURIComponent(message);
  window.location.href=url;
});

renderCategories();
renderProducts();
renderCart();
